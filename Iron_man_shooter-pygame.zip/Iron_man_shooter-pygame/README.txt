Controls:
- UP / DOWN: Move player
- SPACE: Shoot
- R: Restart after game over
